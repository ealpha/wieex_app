package com.wieex.modules.ums.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wieex.modules.ums.model.UmsRoleResourceRelation;

/**
 * 角色资源关系管理Service
 */
public interface UmsRoleResourceRelationService extends IService<UmsRoleResourceRelation> {
}
