package com.wieex.modules.ums.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wieex.modules.ums.model.UmsAdminRoleRelation;

/**
 * 管理员角色关系管理Service
 */
public interface UmsAdminRoleRelationService extends IService<UmsAdminRoleRelation> {
}
