package com.wieex.modules.ums.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wieex.modules.ums.model.UmsRoleMenuRelation;

/**
 * 角色菜单关系管理Service
 */
public interface UmsRoleMenuRelationService extends IService<UmsRoleMenuRelation> {
}
