package com.wieex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WieexApplication {

    public static void main(String[] args) {
        SpringApplication.run(WieexApplication.class, args);
    }

}
